<?php
	include ('includes/sessioncheck.php');
?>

<?php
include "includes/database.php";
 
//Parser for Add Photo Form
if (isset($_POST["photoName"])){
    $photoName = mysqli_real_escape_string( $mysqli, $_POST["photoName"]);
    $category = mysqli_real_escape_string( $mysqli, $_POST["category"]);
 
    //add photo to db
    $sql = mysqli_query( $mysqli, "
               INSERT INTO
                tblPhotos (
                photoName,
                category,
                active
               )VALUES(
                '$photoName',
                '$category',
                '1'
               )") or die(mysql_error());
    $pid = mysqli_insert_id($mysqli);
    $newname = "$pid.jpg";
    move_uploaded_file($_FILES['fileField']['tmp_name'],"galleryPhotos/$newname");
    header("location: addPhotos.php");
    exit();
}
 
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
	<head>
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<meta name="author" content="" />
		<link rel="stylesheet" type="text/css" href="style.css" media="screen" />
		<title>Moja spletna stran</title>
	</head>
	<body>
		<div id="wrapper">
			
			<?php include('includes/header.php'); ?>

			<?php include('includes/nav.php'); ?>


			<div id="content">
				<h3>Add New Photo</h3>
		<form action="addPhotos.php" enctype="multipart/form-data" name="myForm" id="myForm" method="post">
				Photo Name: <input name="photoName" type="text" id="photoName" size="64" /><br />
					Category: <input name="category" type="text" id="category" size="64" /><br />
					Upload Image (jpg only):
					<label>
						<input type="file" name="fileField" id="fileField" />
					</label>
					<label>
						<input type="submit" name="button" id="button" value="Add Photo" />
					</label>
				</form>
			</div> <!-- end #content -->

			<?php include('includes/sidebar.php'); ?>

			<?php include('includes/footer.php'); ?>

		</div> <!-- End #wrapper -->
	</body>
</html>
