

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<meta name="description" content="" />
<meta name="keywords" content="" />
<meta name="author" content="" />
<link rel="stylesheet" type="text/css" href="style.css" media="screen" />
<title>Moja spletna stran</title>
</head>
<body>
    <div id="wrapper">
<?php
	include ('includes/sessioncheck.php');
?>
<?php include('includes/header.php'); ?>

<?php include('includes/nav.php'); ?>

<div id="content">
<h1>Moj Kraj</h1>
<div id="iframe" >
<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d11017.530222045021!2d14.167818250268569!3d46.341951379335875!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x477a961255edcb7b%3A0xb198beb76df8bcc6!2s4240%20Radovljica!5e0!3m2!1ssl!2ssi!4v1621714282795!5m2!1ssl!2ssi" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe>   
</div>


</div> <!-- end #content -->

<?php include('includes/sidebar.php'); ?>

<?php include('includes/footer.php'); ?>
</div> <!-- End #wrapper -->



</body>
</html>
