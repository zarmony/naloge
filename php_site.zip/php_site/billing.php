<?php
	include ('includes/sessioncheck.php');
?>

<?php
	include("includes/db.php");
	include("includes/functions.php");
	
	if(isset($_REQUEST['command']) && isset($_SESSION['cart']))
	{
		if($_REQUEST['command']=='update'){
			$name=$_REQUEST['name'];
			$email=$_REQUEST['email'];
			$address=$_REQUEST['address'];
			$phone=$_REQUEST['phone'];
			$result=$mysqli->query("INSERT INTO `customers` (`serial`, `name`, `email`, `address`, `phone`) VALUES (NULL, '$name','$email','$address','$phone')");
			$customerid=$mysqli->insert_id;
			$date=date('Y-m-d');
			$result=$mysqli->query("INSERT INTO `orders` (`serial`, `date`, `customerid`) VALUES (NULL, '$date', '$customerid')");
			$orderid=$mysqli->insert_id;
			
			$max=count($_SESSION['cart']);
			for($i=0;$i<$max;$i++){
				$pid=$_SESSION['cart'][$i]['productid'];
				$q=$_SESSION['cart'][$i]['qty'];
				$price=get_price($pid);
				
				$mysqli->query("INSERT INTO `order_detail` (`orderid`, `productid`, `quantity`, `price`) VALUES ('$orderid','$pid','$q','$price')");
			}
			die('<html><body><p>Thank You! your order has been placed!</p><p>Please proceed to the <a href="index.php">Login Page</a>.</p></body></html>');
		}
	}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Billing Info</title>
<script language="javascript">
	function validate(){
		var f=document.form1;
		if(f.name.value==''){
			alert('Your name is required');
			f.name.focus();
			return false;
		}
		f.command.value='update';
		f.submit();
	}
</script>
</head>


<body>
	<form name="form1" onsubmit="return validate()">
		<input type="hidden" name="command" />
		<div align="center">
			<h1 align="center">Billing Info</h1>
			<table border="0" cellpadding="2px">
				<tr><td>Your Name:</td><td><input type="text" required name="name"  /></td></tr>
				<tr><td>Address:</td><td><input type="text" required name="address" /></td></tr>
				<tr><td>Email:</td><td><input type="email" required name="email" /></td></tr>
				<tr><td>Phone:</td><td><input type="text" required name="phone" /></td></tr>
				<tr><td>&nbsp;</td><td><input type="submit" value="Place Order" /></td></tr>
			</table>
		</div>
	</form>
	
	<table align="center" border="0" cellpadding="5px" cellspacing="1px" style="font-family:Verdana, Geneva, sans-serif; font-size:11px; background-color:#E1E1E1" width="600px">
	<?php
		if(isset($_SESSION['cart']) && is_array($_SESSION['cart'])){
			echo '<tr bgcolor="#EEE" style="font-weight:bold"><td colspan="5">Products in shopping cart</td></tr>';
			echo '<tr bgcolor="#FFFFFF" style="font-weight:bold"><td>Serial</td><td>Name</td><td>Price</td><td>Qty</td><td>Amount</td></tr>';
			$max=count($_SESSION['cart']);
			for($i=0;$i<$max;$i++){
				$pid=$_SESSION['cart'][$i]['productid'];
				$q=$_SESSION['cart'][$i]['qty'];
				$pname=get_product_name($pid);
				if($q==0) continue;
		?>
				<tr bgcolor="#FFFFFF"><td><?=$i+1?></td><td><?=$pname?></td>
				<td>$ <?=get_price($pid)?></td>
				<td><?php echo $q ?></td>                    
				<td>$ <?=get_price($pid)*$q?></td>
				</tr>
		<?php				
			}
		?>
			<tr><td><b>Order Total: $<?=get_order_total()?></b></td></tr>
		<?php
		}
		else{
			echo "<tr bgColor='#FFFFFF'><td>There are no items in your shopping cart!</td>";
		}
	?>
	</table>
</body>
</html>
