<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
<style>
table {
    border-collapse: collapse;
    width: 70%;
}
th, td {
    text-align: left;
}

tr:nth-child(even){background-color: #E8E8E8}

th {
    background-color: #E8E8E8;
    color: black;
	}
</style>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<meta name="description" content="" />
<meta name="keywords" content="" />
<meta name="author" content="" />
<link rel="stylesheet" type="text/css" href="style.css" media="screen" />
<title>Spletna stran izdelkov</title>
</head>
<body>
<?php
include ('includes/sessioncheck.php');
?>

<div id="wrapper">
<?php include('includes/header.php'); ?>
<?php include('includes/nav.php'); ?>


<div id="content">
	<h1>Seznam produktov</h1><hr>
	<p>Spodnja tabela prikazuje produkte. S klikom na sliko produkta se prikažejo dodatne informacije izbarnega produkta.</p>

<?php
@$con = mysqli_connect("localhost","root","fov","phpsite");
if (!$con){
die("ne morem se povezat" . mysqli_error());
}
mysqli_select_db($con,"phpsite");
$sql = "SELECT * from `products`";
$myData = mysqli_query($con,$sql);


?>
Razvrsti po:<br>
<div>
<form name="po imenu" method="POST" action="#" >
<input type ="submit" name="poimenu" value=" Imenu padajoče">
    <form name="po imenu" method="POST" action="#">
    <input type ="submit" name="poimenu2" value=" Imenu naraščajoče">
        <form name="poceni" method="POST" action="#">
        <input type ="submit" name="poceni" value=" Ceni padajoče">
            <form name="poceni" method="POST" action="#">
            <input type ="submit" name="poceni2" value=" Ceni naraščajoče">
            </form>
        </form>
    </form>
</form>
</div>
<br>
<form  name="search" method="POST" action="/seznam.php" autocomplete="off">
<b >Išči po imenu izdelka: </b><input type="text" name="search_box" id="search_box" size="9">
<input type ="submit" name="search" value="Išči!">
</form>
<hr>
<center>
<?php

if (isset($_POST['poimenu'])) {
	$sql = "SELECT * from `products` ORDER BY name desc";
$myData = mysqli_query($con,$sql);
}
if (isset($_POST['poimenu2'])) {
	$sql = "SELECT * from `products` ORDER BY name";
$myData = mysqli_query($con,$sql);
}
if (isset($_POST['poceni'])) {
	$sql = "SELECT * from `products` ORDER BY price desc";
$myData = mysqli_query($con,$sql);
}
if (isset($_POST['poceni2'])) {
	$sql = "SELECT * from `products` ORDER BY price";
$myData = mysqli_query($con,$sql);
}

if (isset($_POST['search'])) {

$search_term = mysqli_real_escape_string($con,$_POST['search_box']);
$sql = "SELECT * from `products` WHERE (`name`) LIKE '%$search_term%' ";
$myData = mysqli_query($con,$sql);
}
@$query = mysqli_query($con,$sql) or die(mysqli_error($con));

echo "<table border=3>
<tr>
<th  >Serial</th>
<th  >Slika</th>
<th  >Ime</th>
<th  >Cena</th>
<th	 >Opis</th>
</tr>";

$st=1;
while($record = mysqli_fetch_assoc($myData)) {
	// $ocena="★";
echo "<form>";
echo "<tr>";
echo "<td>" . $st . ". " . '<br />';" </td>";
echo "<td>" . '<a href="products.php?name=' . $record["name"].' "><img width="100px" src="' . $record['picture'] . '"><a/>' . '<br />';" </td>";
echo "<td>" . "<input   value='" . $record["name"]. "'</td>";
echo "<td>" . "<input     value='" . $record["price"]. "'</td>";
echo "<td>" . "<input   value='" . $record["description"]. "'</td>";
echo "</tr>";

$st=$st+1;
}
echo "</form>";
echo "</table>";


?>
<br>
</center>	
</div> <!-- end #content -->
<?php include('includes/sidebar.php'); ?>
<?php include('includes/footer.php'); ?>
</div> <!-- End #wrapper -->
<br>
</body>
</html>
