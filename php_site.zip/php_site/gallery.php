<?php
	include ('includes/sessioncheck.php');
?>

<?php
	//connect to db
	include "includes/database.php";
	 
	//check for a page number.If not, set it to page 1
	if (!(isset($_GET['pagenum']))){
		$pagenum = 1;
	}else{
		$pagenum = $_GET['pagenum'];
	}
	 //query for record count to setup pagination
	$data = mysqli_query( $mysqli, "SELECT * FROM tblPhotos WHERE active = 1");
	$rows = mysqli_num_rows($data);
	 //number of photos per page
	$page_rows = 9;
	 //get the last page number
	$last = ceil($rows/$page_rows);
	 //make sure the page number isn't below one, or more than last page num
	if ($pagenum < 1){
		$pagenum = 1;
	}elseif ($pagenum > $last){
		$pagenum = $last;
	}
	 //Set the range to display in query
	$max = 'limit '.($pagenum - 1) * $page_rows.','.$page_rows;
	 
	//get all of the photos
	$dynamicList = "";
	$sql = mysqli_query( $mysqli, "SELECT * FROM tblPhotos WHERE active = 1 $max");
	//check for photos
	$photoCount = mysqli_num_rows($sql);
	 
	if ($photoCount > 0){
		while($row = mysqli_fetch_array($sql)){
				$photoID = $row["photoID"];
				$photoName = $row["photoName"];
				$category = $row["category"];
	 
				$dynamicList.= '
								<div class="thumb">
<a href="photo.php?id='.$photoID.'"><img class="clip" src="galleryPhotos/'.$photoID.'.jpg" alt="'.$photoName.'" width="175" border="0" /></a>
								</div>
								';
		}
	}else{
		$dynamicList = "There are no photos at this time!";
	}
	 
	mysqli_close($mysqli);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
	<head>
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<meta name="author" content="" />
		<link rel="stylesheet" type="text/css" href="style.css" media="screen" />
		<title>Moja spletna stran</title>
	</head>
	<body>
		<div id="wrapper">
			
			<?php include('includes/header.php'); ?>

			<?php include('includes/nav.php'); ?>


			<div id="content">
				    <?php
				echo '<p style="text-align:center; font-weight:bold;">Page '.$pagenum.' of '.$last.'</p>';
				 
						if ($pagenum == 1){
							echo '<div class="pagination" align="center"><ul>';
						}else{
	echo '<div class="pagination" align="center"><ul><li><a href="'.$_SERVER['PHP_SELF'].'?pagenum=1"> first</a></li>'; 
							$previous = $pagenum-1;
						}      
				 
						//check if number of pages is higher than 1
						if($last != 1){
							//Loop from 1 to last page to create page number links
							for($i = 1; $i <= $last; $i++){
					echo '<li><a href="'.$_SERVER['PHP_SELF'].'?pagenum='.$i.'">'.$i.'</a></li>';
							}
						}
				 
						if ($pagenum == $last){
							echo '</div>';
						}else{
							$next = $pagenum+1;
				echo '<li><a href="'.$_SERVER['PHP_SELF'].'?pagenum='.$last.'">last </a></li></ul></div>';
						}
					?>
				 
				<div id="dataGrid">
					<?php echo $dynamicList; ?>
				</div>
			</div> <!-- end #content -->

			<?php include('includes/sidebar.php'); ?>

			<?php include('includes/footer.php'); ?>

		</div> <!-- End #wrapper -->
	</body>
</html>
