<?php
	include ('includes/sessioncheck.php');
?>

<?php
include('includes/database.php');
$error = '';
if(isset($_POST['submit']))
{
	if(isset($_POST['myusername']) && isset($_POST['mypassword']) && isset($_POST['mypasswordrepeat']))
	{
		$myusername = $_POST['myusername']; 
		$mypassword = $_POST['mypassword']; 
		$mypasswordrepeat = $_POST['mypasswordrepeat'];
		if($myusername != '' && $mypassword != '' && $mypasswordrepeat != '')
		{
			if(strcmp($mypassword, $mypasswordrepeat) == 0)
			{
				$myusername = stripslashes($myusername);
				$mypassword = stripslashes($mypassword);
				$myusername = mysqli_real_escape_string($mysqli,$myusername);
				$mypassword = md5(mysqli_real_escape_string($mysqli,$mypassword));
				$sql = mysqli_query( $mysqli, "
					   INSERT INTO 
						members (
						username,
						password                
					   )VALUES(
						'$myusername',
						'$mypassword'
						)") or die(mysqli_error());
				header("location: registrationsuccessful.php");
				exit();
			}
			else
			{
				$error = "Passwords do not match!";
			}
		}
		else
		{
			$error =  "All fields are mandatory!";
		}
	}
	else
	{
		$error =  "All fields are mandatory!";
	}
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
	<head>
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<meta name="author" content="" />
		<link rel="stylesheet" type="text/css" href="style.css" media="screen" />
		<title>1stWebDesigner PHP Template</title>
	</head>
	<body>
		<div id="wrapper">
			<div id="header">
				<?php include('includes/header.php'); ?>
			</div> <!-- end #header -->
			<div id="content">
				<br/>
				<br/>
				<table width="300" border="0" align="center" cellpadding="0" cellspacing="1">
					<tr>
					<form name="registration" method="post" action="<?php echo($_SERVER['PHP_SELF']) ?>">
					<td>
					<table width="100%" border="0" cellpadding="3" cellspacing="1" bgcolor="#FFFFFF">
					<tr>
					<td colspan="3"><strong>Member registration </strong></td>
					</tr>
					<tr>
					<td width="78">Username</td>
					<td width="6">:</td>
					<td width="294"><input name="myusername" type="text" id="myusername"></td>
					</tr>
					<tr>
					<td>Password</td>
					<td>:</td>
					<td><input name="mypassword" type="password" id="mypassword"></td>
					</tr>
					<tr>
					<td>Repeat Password</td>
					<td>:</td>
					<td><input name="mypasswordrepeat" type="password" id="mypasswordrepeat"></td>
					</tr>			
					<tr>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td><input type="submit" name="submit" value="Register"></td>
					</tr>
					<tr>
					<td colspan="3" style="color:red;"><?php echo $error ?></td>
					</tr>
					</table>
					</td>
					</form>
					</tr>
				</table>
				<br/>
				<br/>
			</div> <!-- end #content -->
			<div id="footer">
				<?php include('includes/footer.php'); ?>
			</div> <!-- end #footer -->
		</div> <!-- end #wrapper -->
	</body>
</html>
