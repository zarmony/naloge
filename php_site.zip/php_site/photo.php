<?php
//connect to db
include "includes/database.php";
 
//initialize some vars
$photoID = '';
$photoName = '';
$category = '';
 
//check what photo we are looking for

if(isset($_GET['id'])){
    $photoID = mysqli_real_escape_string( $mysqli, $_GET ['id']);
    //get the photo
    $sql = mysqli_query( $mysqli, "SELECT * FROM tblPhotos WHERE photoID='$photoID' LIMIT 1");
    while($row = mysqli_fetch_array($sql)){
        $photoName = $row['photoName'];
        $category = $row['category'];
    }
}else{
    echo 'No photo was selected!';
    exit();
}
 
mysqli_close($mysqli);
 
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Tech Remedy Gallery Demo - <?php echo $photoName; ?></title>
</head>
 
<body>
<div id="photo">
    <img src="galleryPhotos/<?php echo $photoID; ?>.jpg" alt="<?php echo $photoName; ?>" width="400" /><br />
    <h2><?php echo $photoName; ?></h2>
    <p><?php echo $category; ?></p>
</div>
</body>
</html>
