

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<meta name="description" content="" />
<meta name="keywords" content="" />
<meta name="author" content="" />
<link rel="stylesheet" type="text/css" href="style.css" media="screen" />
<title>Moja spletna stran</title>
</head>
<body>
    <div id="wrapper">
<?php
	include ('includes/sessioncheck.php');
?>
<?php include('includes/header.php'); ?>

<?php include('includes/nav.php'); ?>

<div id="content">
<h1>Domov</h1>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas elementum, lorem id ultrices auctor, tellus odio dignissim velit, faucibus posuere nisl elit nec est. Aenean ac ipsum velit, ac aliquam neque. Suspendisse potenti. Nam non lacus ac neque bibendum suscipit. Donec ac metus in massa malesuada imperdiet. Vestibulum vel justo sit amet velit fringilla gravida eget ac dolor. Donec luctus sem ac mi vulputate nec fringilla lorem vestibulum.</p>
	<p>Duis fermentum consequat magna, vel varius ligula aliquet in. Morbi vel dui ac tortor fringilla auctor. Integer congue nisl non ante dapibus tincidunt. Fusce est dolor, convallis nec vulputate id, ultrices ac tellus. Curabitur a ullamcorper enim. Ut semper eros vel augue ullamcorper consectetur. Vivamus nec ultricies est. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Fusce vitae lorem dolor. Integer imperdiet commodo tincidunt. Ut elementum blandit tempus. Suspendisse nec commodo dui.</p>
	<p>Vivamus sed neque metus, ac imperdiet dolor. Proin bibendum tortor sagittis metus dapibus tristique. Nam id gravida massa. Quisque at pulvinar magna. Ut eget tortor eu turpis fermentum molestie vel nec ipsum. Cras ultrices, ligula eu ornare dapibus, metus nisi tincidunt felis, eu porttitor augue risus id lacus. Donec a enim sit amet lectus condimentum consectetur non sed velit. Quisque pretium placerat nibh, nec mollis diam tristique eget. Phasellus non est in turpis blandit varius ut vitae diam. Cras quis purus eget diam rhoncus scelerisque. Vestibulum ac arcu metus, sodales dictum lorem. Morbi eget libero ipsum. Praesent iaculis justo vel leo aliquam vestibulum. Phasellus quis erat id justo adipiscing adipiscing.</p>


</div> <!-- end #content -->

<?php include('includes/sidebar.php'); ?>

<?php include('includes/footer.php'); ?>
</div> <!-- End #wrapper -->



</body>
</html>
