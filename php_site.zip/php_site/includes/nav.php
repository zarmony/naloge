<div id="nav">
<a href="index.php">Domov</a>
<a href="onas.php">Video</a>
<a href="portfolio.php">Twitter feed</a>
<a href="knjigagostov.php">Knjiga gostov</a>
<a href="kontakt.php">Kontakt</a>
<a href="gallery.php">Galerija</a>
<a href="addPhotos.php">Dodaj sliko</a>
<a href="products.php">Produkti</a>
<a href="seznam.php">Seznam</a><br><br>
<a href="mojseznam.php">Moj seznam</a>
<a href="kraj.php">Kraj</a>
</div> <!-- end #nav -->
