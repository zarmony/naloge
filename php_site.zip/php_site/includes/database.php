<?php
	$server = "localhost";
	$username = "root";
	$password = "fov";
	$dbname = "phpsite";
$mysqli = new mysqli($server, $username, $password, $dbname);
?>
