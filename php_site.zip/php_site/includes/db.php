<?php
	
	//@mysql_connect("localhost","root","fov") or die("Demo is not available, please try again later");
	//@mysql_select_db("website") or die("Demo is not available, please try again later");
	$mysqli	= new mysqli("localhost", "root", "fov", "phpsite");


	if ($mysqli->connect_errno) {
		printf("Connect failed: %s\n", $mysqli->connect_error);
		exit();
	}
	if (session_status() == PHP_SESSION_NONE) {
    session_start();
	}
?>
