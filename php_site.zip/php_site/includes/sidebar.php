

<div id="sidebar">
<h3>Navigacija</h3>
	<li><a href="index.php">Domov</a></li>
	<li><a href="onas.php">Video</a></li>
	<li><a href="portfolio.php">Twitter feed</a></li>
	<li><a href="knjigagostov.php">Knjiga gostov</a></li>
	<li><a href="kontakt.php">Kontakt</a></li>
    <li><a href="gallery.php">Galerija</a></li>
    <li><a href="addPhotos.php">Dodaj sliko</a></li>
    <li><a href="products.php">Produkti</a></li>
    <li><a href="seznam.php">Seznam</a></li>
    <li><a href="mojseznam.php">Moj seznam</a></li>
    <li><a href="kraj.php">Kraj</a></li>
    
<li><h4>Pozdravljen<strong> <?php echo $_SESSION['myusername']?>.</strong>
<a id="vreme" href="logout.php">Logout</a><h4></li>
<li><a><!-- weather widget start --><a target="_blank" href="https://www.booked.net/weather/ljubljana-2983"><img src="https://w.bookcdn.com/weather/picture/32_2983_1_1_34495e_250_2c3e50_ffffff_ffffff_1_2071c9_ffffff_0_6.png?scode=124&domid=w209&anc_id=62242"  alt="booked.net"/></a><!-- weather widget end --></a></li></div>
<div id="sidebar">  



</div> <!-- end #sidebar -->
