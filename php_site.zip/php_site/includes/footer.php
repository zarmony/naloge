<div id="footer">
	<p>Copyright @ 2010 - 2021 <a href="http://www.1stwebdesigner.com" target="_blank">1stWebDesigner.com PHP Template</a></p>
</div> <!-- end #footer -->
