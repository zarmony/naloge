<?php
session_start();
if(!$_SESSION['myusername'])
{
	//echo ("Not registered!");
	header("location:login.php");
}
?>
