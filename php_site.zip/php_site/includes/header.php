<div id="header" >
	<a href="http://localhost/php_site/index.php"><img  src="neon1.png" alt="Flowers in Chania" width="200" height="90" ></a>
</div> <!-- end #header -->
