

<?php
include('includes/database.php');
$error = '';
// username and password sent from form 
if(isset($_POST['submit']))
{
	if(isset($_POST['myusername']) && isset($_POST['mypassword']))
	{
		$myusername = $_POST['myusername']; 
		$mypassword = $_POST['mypassword']; 
		// To protect MySQL injection (more detail about MySQL injection)
		$myusername = stripslashes($myusername);
		$mypassword = stripslashes($mypassword);
		$myusername = mysqli_real_escape_string( $mysqli,$myusername);
		$mypassword = mysqli_real_escape_string($mysqli,$mypassword);
		$mypassword = md5($mypassword);
		$sql = "SELECT * FROM members WHERE username='$myusername' and password='$mypassword'";
		$result = mysqli_query( $mysqli, $sql);
		// Mysql_num_row is counting table row
		$rowcount = mysqli_num_rows($result);
		
		// If result matched $myusername and $mypassword, table row must be 1 row
		if($rowcount == 1){
			// Register $myusername, $mypassword and redirect to file "index.php"
			session_start();
			$_SESSION['myusername'] = $myusername;
			$_SESSION['mypassword'] = $mypassword;
			header("location:index.php");
		}
		else {
			$error = "Wrong Username or Password!";
		}
	}
	else
	{
		$error = "Please provide Username and/or Password!";
	}
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
	<head>
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<meta name="author" content="" />
		<link rel="stylesheet" type="text/css" href="style.css" media="screen" />
		<title>1stWebDesigner PHP Template</title>
<script language="javascript">
            function validate(){
                var f=document.login;
                var error = false;
               // preverjati pricnemo na koncu, da pride potem focus na prvo manjkajoce polje od zgoraj!
                if(f.mypassword.value==''){
                    document.getElementById("password_error").style.color="red";
                    f.mypassword.focus();
                    error = true;
                }
                else
                {
                    document.getElementById("password_error").style.color="#f8f8f8";
                }
                if(f.myusername.value==''){
                    document.getElementById("username_error").style.color="red";
                    f.myusername.focus();
                    error = true;
                }
                else
                {
                    document.getElementById("username_error").style.color="#f8f8f8";
                }
                if(error)
                    return false;
               //f.command.value='update';
                f.submit();
            }
        </script>
	</head>
	<body>
		<div id="wrapper">
			<div id="header">
				<?php include('includes/header.php'); ?>
			</div> <!-- end #header -->
			<div id="content">
				<br/>
				<br/>
				<table width="300" border="0" align="center" cellpadding="0" cellspacing="1" >
					<tr>
					<form name="login" method="post" action="<?php echo($_SERVER['PHP_SELF']) ?>">
					<td>
					<table width="100%" border="0" cellpadding="3" cellspacing="1" bgcolor="#FFFFFF">
					<tr>
					<td colspan="3"><strong>Member Login </strong></td>
					</tr>
					<tr>
					<td width="78">Username</td>
					<td width="6">:</td>
					<td width="294"><input name="myusername" type="text" id="myusername"></td>
					</tr>
					<tr>
					<td>Password</td>
					<td>:</td>
					<td><input name="mypassword" type="password" id="mypassword"></td>
					</tr>
					<tr>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td><input type="submit" name="submit" value="Login"></td>
					</tr>
					<tr>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td><a href="register.php">Register</a>
					</tr>
					<tr>
					<td colspan="3" style="color:red;"><?php echo $error ?></td>
					</tr>
					</table>
					</td>
					</form>
					</tr>
				</table>
				<br/>
				<br/>
			</div> <!-- end #content -->
			<div id="footer">
				<?php include('includes/footer.php'); ?>
			</div> <!-- end #footer -->
		</div> <!-- end #wrapper -->
	</body>
</html>
