<?php
	include ('includes/sessioncheck.php');
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
	<head>
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<meta name="author" content="" />
		<link rel="stylesheet" type="text/css" href="style.css" media="screen" />
		<title>1stWebDesigner PHP Template</title>
	</head>
	<body>
		<div id="wrapper">
			<div id="header">
				<?php include('includes/header.php'); ?>
			</div> <!-- end #header -->
			<div id="content">
				<br/>
				<br/>
				<p>You have been registered successfully!
				</p>
				<p>Please proceed to the <a href="login.php">Login page</a>.
				</p>
				<br/>
				<br/>				
			</div> <!-- end #content -->
			<div id="footer">
				<?php include('includes/footer.php'); ?>
			</div> <!-- end #footer -->
		</div> <!-- end #wrapper -->
	</body>
</html>
