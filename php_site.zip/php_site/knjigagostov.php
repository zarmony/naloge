<?php
	include ('includes/sessioncheck.php');
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">

<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<meta name="description" content="" />
	<meta name="keywords" content="" />
	<meta name="author" content="" />
	<link rel="stylesheet" type="text/css" href="style.css" media="screen" />
	<title>Moja spletna stran</title>

<script>       
function Vnesi() {
  var x = document.forms["forma"]["email"].value;
  var y = document.forms["forma"]["name"].value;
  var z = document.forms["forma"]["message"].value;
  if (x == "") {
    alert("Email mora biti izpolnjen!");
    return false;
  }
  else if (y == "") {
    alert("Prosim vpišite ime");
    return false;
  }
    if (z == "") {
    alert("Prosim vnesite sporočilo");
    return false;
  }
}
</script>
</head>
	<body>
		<div id="wrapper">
			<?php include('includes/header.php'); ?>

			<?php include('includes/nav.php'); ?>

			<div id="content">
				<h1>Knjiga gostov</h1>

				<?php
					if(isset($_POST['submit']) && $_POST['name'] && $_POST['email'] && $_POST['message'])
					{
						require_once('includes/db.php');
						
						$name = $_POST['name'];
						$email = $_POST['email'];
						$message = $_POST['message'];
						$date = date("Y-m-d H:i:s", time());
						
$sql = mysqli_query($mysqli,"INSERT INTO guestbook (ime, eposta, sporocilo, datum) VALUES ('$name','$email','$message','$date')");

						header('Location: '. $_SERVER['PHP_SELF']);
					}
				?>
				
				<form name="forma" onsubmit="Vnesi()" method="post"  action="<?php echo $_SERVER['PHP_SELF']; ?>">
					<table cellpadding="6" cellspacing="0">
						<tr>
							<td>Ime:</td>
							<td><input type="text" name="name" /></td>
						</tr>

						<tr>
							<td>Email:</td>
							<td><input type="text" name="email" /></td>
						</tr>

						<tr>
							<td valign="top">Sporočilo:</td>
							<td><textarea name="message" cols="60" rows="4"></textarea></td>
						</tr>

						<tr>
							<td> </td>
							<td>
								<input type="submit" name="submit" value="Dodaj" />
								<input type="reset" name="reset" value="Izbriši" />
							</td>
						</tr>
					</table>
				</form>
				
				<hr/>
				
				<?php
					require_once('includes/database.php');
					
				$sql = mysqli_query($mysqli, "SELECT ime, eposta, sporocilo, datum FROM guestbook ORDER BY id DESC LIMIT 10");
				
					if($sql) {
						while($data = mysqli_fetch_array($sql)) {
							$post_date = $data['datum'];
							$name = $data['ime'];
							$email = $data['eposta'];
							$message = $data['sporocilo'];
							echo "<div>$post_date je <a href=\"mailto:$email\">$name</a> rekel:</div>\n";
							echo "<div>$message</div><br/>";
						}
					}

				?>
			</div> <!-- end #content -->

			<?php include('includes/sidebar.php'); ?>

			<?php include('includes/footer.php'); ?>
		</div> <!-- End #wrapper -->

        
	</body>
</html>
